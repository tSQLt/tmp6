EXEC tSQLt.NewTestClass 'InstallAssemblyKeyTests';
GO
DECLARE @cmd NVARCHAR(MAX);
SET @cmd = 'IF(SUSER_ID(''InstallAssemblyKeyTestsUser1'')) IS NOT NULL DROP LOGIN InstallAssemblyKeyTestsUser1;';
EXEC master.sys.sp_executesql @cmd;
SET @cmd = 'IF(SCHEMA_ID(''InstallAssemblyKeyTestsUser1'')) IS NOT NULL DROP SCHEMA InstallAssemblyKeyTestsUser1;';
EXEC master.sys.sp_executesql @cmd;
EXEC sys.sp_executesql @cmd;
SET @cmd = 'IF(USER_ID(''InstallAssemblyKeyTestsUser1'')) IS NOT NULL DROP USER InstallAssemblyKeyTestsUser1;';
EXEC master.sys.sp_executesql @cmd;
EXEC sys.sp_executesql @cmd;
GO
CREATE PROCEDURE InstallAssemblyKeyTests.DropExistingItems
AS
BEGIN
  IF SUSER_ID('tSQLtAssemblyKey') IS NOT NULL DROP LOGIN tSQLtAssemblyKey;
  EXEC master.sys.sp_executesql N'IF ASYMKEY_ID(''tSQLtAssemblyKey'') IS NOT NULL DROP ASYMMETRIC KEY tSQLtAssemblyKey;';
  EXEC master.sys.sp_executesql N'IF EXISTS(SELECT * FROM sys.assemblies WHERE name = ''tSQLtAssemblyKey'') DROP ASSEMBLY tSQLtAssemblyKey;';
  
  DECLARE @ProductMajorVersion INT;
  EXEC @ProductMajorVersion = tSQLt.Private_GetSQLProductMajorVersion;
  IF(@ProductMajorVersion>=14)
  BEGIN
    DECLARE @cmd NVARCHAR(MAX);
    SELECT @cmd = 
    '
      DECLARE @cmd NVARCHAR(MAX);
      SELECT @cmd = 
      (
        SELECT ''EXEC sys.sp_drop_trusted_assembly @hash = '' + CONVERT(NVARCHAR(MAX),TA.[hash],1) + '';'' FROM sys.trusted_assemblies AS TA
           FOR XML PATH(''''),TYPE
      ).value(''.'',''NVARCHAR(MAX)'');
      EXEC(@cmd);
    ';
    EXEC(@cmd);
  END;
--SELECT * FROM sys.trusted_assemblies AS TA   
END;
GO
CREATE PROCEDURE InstallAssemblyKeyTests.[test tSQLtAssemblyKey install data is signed with same key as tSQLt.clr]
AS
BEGIN
  DECLARE @EAKey VARBINARY(100);
  DECLARE @tSQLtKey VARBINARY(100);
  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyThumbPrint = @EAKey OUT;
  SELECT @tSQLtKey = I.ClrSigningKey
    FROM tSQLt.Info() AS I;
  EXEC tSQLt.AssertEquals @Expected = @tSQLtKey, @Actual = @EAKey;
END;
GO
CREATE PROCEDURE InstallAssemblyKeyTests.[test creates correct asymmetric key in master]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;
  
  EXEC tSQLt.InstallAssemblyKey;

  DECLARE @KeyInfoPattern NVARCHAR(MAX);
  
  SELECT @KeyInfoPattern = '%publickeytoken='+LOWER(CONVERT(NVARCHAR(MAX),AK.thumbprint,2))+',%'
    FROM master.sys.asymmetric_keys AS AK 
   WHERE AK.name = 'tSQLtAssemblyKey';


  DECLARE @tSQLtCLRInfo VARCHAR(MAX);
  SELECT @tSQLtCLRInfo = A.clr_name FROM sys.assemblies AS A WHERE name = 'tSQLtCLR';

  EXEC tSQLt.AssertLike @ExpectedPattern = @KeyInfoPattern, @Actual = @tSQLtCLRInfo;
END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test works if any assembly with the name tSQLtAssemblyKey already exists]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  EXEC tSQLt.InstallAssemblyKey;

  DECLARE @cmd NVARCHAR(MAX);

  DECLARE @ProductMajorVersion INT;
  EXEC @ProductMajorVersion = tSQLt.Private_GetSQLProductMajorVersion;
  IF(@ProductMajorVersion>=14)
  BEGIN
    -- sp_add_trusted_assembly is new (and required) in 2017
    SELECT @cmd = 
           'EXEC sys.sp_add_trusted_assembly @hash = ' + CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',PGEAKB.UnsignedEmptyBytes),1) + ', @description = N''tSQLt Ephemeral'';'
      FROM tSQLt_testutil.GetUnsignedEmptyBytes() AS PGEAKB;
  
    EXEC master.sys.sp_executesql @cmd;
  END;

  SELECT @cmd = 
         'CREATE ASSEMBLY tSQLtAssemblyKey AUTHORIZATION dbo FROM ' +
         CONVERT(NVARCHAR(MAX),GUEB.UnsignedEmptyBytes,1) +
         ' WITH PERMISSION_SET = SAFE;'       
    FROM tSQLt_testutil.GetUnsignedEmptyBytes() AS GUEB;
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.ExpectNoException;  
  EXEC tSQLt.InstallAssemblyKey;

END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test works if a tSQLtAssemblyKey assembly already exists under different name]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);

  DECLARE @ProductMajorVersion INT;
  EXEC @ProductMajorVersion = tSQLt.Private_GetSQLProductMajorVersion;
  IF(@ProductMajorVersion>=14)
  BEGIN
    -- sp_add_trusted_assembly is new (and required) in 2019
    DECLARE @AssemblyKeyBytes VARBINARY(MAX);
    EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;

    SELECT @cmd = 
           'EXEC sys.sp_add_trusted_assembly @hash = ' + CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1) + ', @description = N''tSQLt Ephemeral'';';
  
    EXEC master.sys.sp_executesql @cmd;
  END;

  SELECT @cmd = 
         'CREATE ASSEMBLY [tSQLtAssemblyKey with wrong name!] AUTHORIZATION dbo FROM ' +
         CONVERT(NVARCHAR(MAX),@AssemblyKeyBytes,1) +
         ' WITH PERMISSION_SET = SAFE;';
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.InstallAssemblyKey;

END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test drops assembly when done]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;
  
  EXEC tSQLt.InstallAssemblyKey;

  SELECT *
    INTO #Actual
    FROM master.sys.assemblies AS A
   WHERE A.name = 'tSQLtAssemblyKey'
      OR A.clr_name LIKE 'tsqltAssemblyKey, %';
  EXEC tSQLt.AssertEmptyTable @TableName = '#Actual';
END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test creates login based on the new asymmetric key]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;
  
  EXEC tSQLt.InstallAssemblyKey;

  SELECT SP.name login_name,
         AK.name asymmetric_key_name,
         SP.type_desc 
    INTO #Actual
    FROM master.sys.server_principals AS SP
    JOIN master.sys.asymmetric_keys AS AK
      ON SP.sid = AK.sid
   WHERE SP.name = 'tSQLtAssemblyKey'
  
  SELECT TOP(0) *
  INTO #Expected
  FROM #Actual;
  INSERT INTO #Expected
  VALUES('tSQLtAssemblyKey','tSQLtAssemblyKey','ASYMMETRIC_KEY_MAPPED_LOGIN');

  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test works if a tSQLtAssemblyKey asymmetric key already exists]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);

  SELECT @cmd = 'CREATE ASYMMETRIC KEY tSQLtAssemblyKey WITH ALGORITHM = RSA_2048 ENCRYPTION BY PASSWORD = '''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''';';
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.InstallAssemblyKey;

END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test works if a tSQLtAssemblyKey asymmetric key already exists under different name]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @AssemblyKeyBytes VARBINARY(MAX);
  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;

  DECLARE @cmd NVARCHAR(MAX);

  DECLARE @ProductMajorVersion INT;
  EXEC @ProductMajorVersion = tSQLt.Private_GetSQLProductMajorVersion;
  IF(@ProductMajorVersion>=14)
  BEGIN
    -- sp_add_trusted_assembly is new (and required) in 2019
    SELECT @cmd = 
           'EXEC sys.sp_add_trusted_assembly @hash = ' + CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1) + ', @description = N''tSQLt Ephemeral'';';
  
    EXEC master.sys.sp_executesql @cmd;
  END;

  SELECT @cmd = 
         'CREATE ASSEMBLY [tSQLtAssemblyKey with wrong name!] AUTHORIZATION dbo FROM ' +
         CONVERT(NVARCHAR(MAX),@AssemblyKeyBytes,1) +
         ' WITH PERMISSION_SET = SAFE;';
  EXEC master.sys.sp_executesql @cmd;
  
  SET @cmd = 'CREATE ASYMMETRIC KEY [tSQLtAssemblyKey->asymmetric key with wrong name!] FROM ASSEMBLY [tSQLtAssemblyKey with wrong name!];';
  EXEC master.sys.sp_executesql @cmd;

  SET @cmd = 'DROP ASSEMBLY [tSQLtAssemblyKey with wrong name!];';
  EXEC master.sys.sp_executesql @cmd;

  EXEC tSQLt.InstallAssemblyKey;
END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test works if a tSQLtAssemblyKey asymmetric key/login pair already exists under different name]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @AssemblyKeyBytes VARBINARY(MAX);
  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;

  DECLARE @cmd NVARCHAR(MAX);

  DECLARE @ProductMajorVersion INT;
  EXEC @ProductMajorVersion = tSQLt.Private_GetSQLProductMajorVersion;
  IF(@ProductMajorVersion>=14)
  BEGIN
    -- sp_add_trusted_assembly is new (and required) in 2019
    SELECT @cmd = 
           'EXEC sys.sp_add_trusted_assembly @hash = ' + CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1) + ', @description = N''tSQLt Ephemeral'';';
  
    EXEC master.sys.sp_executesql @cmd;
  END;

  SELECT @cmd = 
         'CREATE ASSEMBLY [tSQLtAssemblyKey with wrong name!] AUTHORIZATION dbo FROM ' +
         CONVERT(NVARCHAR(MAX),@AssemblyKeyBytes,1) +
         ' WITH PERMISSION_SET = SAFE;';
  EXEC master.sys.sp_executesql @cmd;
  
  SET @cmd = 'CREATE ASYMMETRIC KEY [tSQLtAssemblyKey->asymmetric key with wrong name!] FROM ASSEMBLY [tSQLtAssemblyKey with wrong name!];';
  EXEC master.sys.sp_executesql @cmd;

  SET @cmd = 'CREATE LOGIN [tSQLtAssemblyKey->server principal with wrong name!] FROM ASYMMETRIC KEY [tSQLtAssemblyKey->asymmetric key with wrong name!];';
  EXEC master.sys.sp_executesql @cmd;

  SET @cmd = 'DROP ASSEMBLY [tSQLtAssemblyKey with wrong name!];';
  EXEC master.sys.sp_executesql @cmd;

  EXEC tSQLt.InstallAssemblyKey;

END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test works if a tSQLtAssemblyKey login already exists]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);

  SELECT @cmd = 'CREATE LOGIN tSQLtAssemblyKey WITH PASSWORD = '''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''',CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;';
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.InstallAssemblyKey;

END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test non-sysadmin cannot execute procedure]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);
    
  SET @cmd = 'CREATE LOGIN InstallAssemblyKeyTestsUser1 WITH PASSWORD='''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''';';
  EXEC master.sys.sp_executesql @cmd;

  SET @cmd = 'CREATE USER InstallAssemblyKeyTestsUser1;ALTER ROLE db_owner ADD MEMBER InstallAssemblyKeyTestsUser1;';
  IF((SELECT I.SqlVersion FROM tSQLt.Info() AS I) < 11)
  BEGIN
    SET @cmd = 'CREATE USER InstallAssemblyKeyTestsUser1;EXEC sys.sp_addrolemember @rolename = ''db_owner'', @membername = ''InstallAssemblyKeyTestsUser1'';';
  END
  EXEC master.sys.sp_executesql @cmd;
  EXEC sys.sp_executesql @cmd;
  
  EXEC tSQLt.ExpectException @ExpectedMessage = 'Only principals with CONTROL SERVER permission can execute this procedure.';
  
  EXECUTE AS LOGIN = 'InstallAssemblyKeyTestsUser1';
  EXEC tSQLt.InstallAssemblyKey;
  REVERT;

END;
GO

CREATE PROCEDURE InstallAssemblyKeyTests.[test sysadmin can execute procedure]
AS
BEGIN

    EXEC InstallAssemblyKeyTests.DropExistingItems;

    DECLARE @cmd NVARCHAR(MAX);
    
    SET @cmd = 'CREATE LOGIN InstallAssemblyKeyTestsUser1 WITH PASSWORD='''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''';';
    EXEC master.sys.sp_executesql @cmd;

    SET @cmd = 'GRANT CONTROL SERVER TO InstallAssemblyKeyTestsUser1;';
    EXEC master.sys.sp_executesql @cmd;
  
    EXEC tSQLt.ExpectNoException;
  
    EXECUTE AS LOGIN = 'InstallAssemblyKeyTestsUser1';
    EXEC tSQLt.InstallAssemblyKey;
    REVERT;

END;
GO
CREATE PROCEDURE InstallAssemblyKeyTests.[test tSQLt can be set to EXTERNAL ACCESS after InstallAssemblyKey executed]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  EXEC tSQLt.InstallAssemblyKey;

  EXEC tSQLt.ExpectNoException;

  ALTER ASSEMBLY tSQLtCLR WITH PERMISSION_SET = EXTERNAL_ACCESS;  

END;
GO

------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------
---- run following tests with clr strict security = 1 ------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE InstallAssemblyKeyTests.[test can install key even if clr strict security is set to 1]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;
  
  EXEC tSQLt.InstallAssemblyKey;

  SELECT SP.name login_name,
         AK.name asymmetric_key_name,
         SP.type_desc 
    INTO #Actual
    FROM master.sys.server_principals AS SP
    JOIN master.sys.asymmetric_keys AS AK
      ON SP.sid = AK.sid
   WHERE SP.name = 'tSQLtAssemblyKey'
  
  SELECT TOP(0) *
  INTO #Expected
  FROM #Actual;
  INSERT INTO #Expected
  VALUES('tSQLtAssemblyKey','tSQLtAssemblyKey','ASYMMETRIC_KEY_MAPPED_LOGIN');

  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';

END;
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE InstallAssemblyKeyTests.[test works if trusted assembly entry exists already]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @AssemblyKeyBytes VARBINARY(MAX);
  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;
  
  DECLARE @cmd NVARCHAR(MAX);
  SELECT @cmd = 
         'EXEC sys.sp_add_trusted_assembly @hash = ' + CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1) + ', @description = N''tSQLt Ephemeral'';';
  EXEC master.sys.sp_executesql @cmd;

  EXEC tSQLt.ExpectNoException;  
  EXEC tSQLt.InstallAssemblyKey;

END;
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE InstallAssemblyKeyTests.[test removes trusted assembly record when done]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;
  
  EXEC tSQLt.InstallAssemblyKey;

  SELECT * INTO #Actual FROM sys.trusted_assemblies AS TA WHERE TA.description = 'tSQLt Ephemeral';

  EXEC tSQLt.AssertEmptyTable @TableName = '#Actual';

END;
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE InstallAssemblyKeyTests.[test does not remove trusted assembly record if it already exists (based on hash)]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @AssemblyKeyBytes VARBINARY(MAX);
  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;

  DECLARE @Hash NVARCHAR(MAX) = CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1);

  DECLARE @cmd NVARCHAR(MAX);
  SELECT @cmd = 'EXEC sys.sp_add_trusted_assembly @hash = ' + @Hash + ', @description = N''some random description'';'
  EXEC master.sys.sp_executesql @cmd;

  EXEC tSQLt.InstallAssemblyKey;

  SELECT TA.hash, TA.description INTO #Actual FROM sys.trusted_assemblies AS TA;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  INSERT INTO #Expected VALUES(CONVERT(VARBINARY(64),@Hash,1), 'some random description'); --failing this on purpose. Fix me.
  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
END;
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE InstallAssemblyKeyTests.[test removes trusted assembly record if it already exists (based on hash) and has the tSQLt Ephemeral description]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;

  DECLARE @AssemblyKeyBytes VARBINARY(MAX);
  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;

  DECLARE @Hash NVARCHAR(MAX) = CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1);

  DECLARE @cmd NVARCHAR(MAX);
  SELECT @cmd = 'EXEC sys.sp_add_trusted_assembly @hash = ' + @Hash + ', @description = N''tSQLt Ephemeral'';'
  EXEC master.sys.sp_executesql @cmd;

  EXEC tSQLt.InstallAssemblyKey;

  SELECT * INTO #Actual FROM sys.trusted_assemblies AS TA WHERE TA.description = 'tSQLt Ephemeral';

  EXEC tSQLt.AssertEmptyTable @TableName = '#Actual';
END;
GO
--[@tSQLt:MaxSqlMajorVersion](13)
CREATE PROCEDURE InstallAssemblyKeyTests.[test grants EXTERNAL ACCESS ASSEMBLY permission to new login pre SQL 2017]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;
  
  EXEC tSQLt.InstallAssemblyKey;

  SELECT SP.class_desc,
         SP.permission_name,
         SP.state_desc
    INTO #Actual
    FROM sys.server_permissions AS SP
   WHERE SP.grantee_principal_id = SUSER_ID('tSQLtAssemblyKey')
     AND SP.permission_name LIKE '%ASSEMBLY'

  SELECT TOP(0) *
  INTO #Expected
  FROM #Actual;

  INSERT INTO #Expected
  VALUES('SERVER','EXTERNAL ACCESS ASSEMBLY','GRANT');
  
  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';  
END;
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE InstallAssemblyKeyTests.[test grants UNSAFE ASSEMBLY permission to new login in SQL 2017 and later]
AS
BEGIN
  EXEC InstallAssemblyKeyTests.DropExistingItems;
  
  EXEC tSQLt.InstallAssemblyKey;

  SELECT SP.class_desc,
         SP.permission_name,
         SP.state_desc
    INTO #Actual
    FROM sys.server_permissions AS SP
   WHERE SP.grantee_principal_id = SUSER_ID('tSQLtAssemblyKey')
     AND SP.permission_name LIKE '%ASSEMBLY'

  SELECT TOP(0) *
  INTO #Expected
  FROM #Actual;

  INSERT INTO #Expected
  VALUES('SERVER','UNSAFE ASSEMBLY','GRANT');
  
  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';  
END;
GO


GO

EXEC tSQLt.NewTestClass 'InstallExternalAccessKeyTests';
GO
CREATE PROCEDURE InstallExternalAccessKeyTests.[test calls tSQLt.InstallAssemblyKey]
AS
BEGIN
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.InstallAssemblyKey';

  EXEC tSQLt.InstallExternalAccessKey;

  SELECT _id_ INTO #Actual FROM tSQLt.InstallAssemblyKey_SpyProcedureLog;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  
  INSERT INTO #Expected VALUES (1);

  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
  
END;
GO

CREATE PROCEDURE InstallExternalAccessKeyTests.[test prints sensible deprecation warning]
AS
BEGIN
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.InstallAssemblyKey';
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.Private_Print';

  EXEC tSQLt.InstallExternalAccessKey;

  SELECT Message INTO #Actual FROM tSQLt.Private_Print_SpyProcedureLog ;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  INSERT INTO #Expected VALUES('tSQLt.InstallExternalAccessKey is deprecated. Please use tSQLt.InstallAssemblyKey instead.');

  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
  
END;
GO


GO

EXEC tSQLt.NewTestClass 'PrepareServerTests';
GO
CREATE PROCEDURE PrepareServerTests.[test enables CLR]
AS
BEGIN
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.Private_EnableCLR';
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.InstallAssemblyKey';


  EXEC tSQLt.PrepareServer;

  SELECT COUNT(1) NumberOfCalls
    INTO #Actual
    FROM tSQLt.Private_EnableCLR_SpyProcedureLog;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  INSERT INTO #Expected VALUES(1);
  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
  
END;
GO
CREATE PROCEDURE PrepareServerTests.[test calls tSQLt.InstallAssemblyKey]
AS
BEGIN
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.Private_EnableCLR';
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.InstallAssemblyKey';

  EXEC tSQLt.PrepareServer;

  SELECT COUNT(1) NumberOfCalls
    INTO #Actual
    FROM tSQLt.InstallAssemblyKey_SpyProcedureLog;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  INSERT INTO #Expected VALUES(1);
  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
  
END;
GO
CREATE PROCEDURE PrepareServerTests.[test calls tSQLt.InstallAssemblyKey after tSQLt.Private_EnableCLR]
AS
BEGIN
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.Private_EnableCLR', @CommandToExecute='INSERT INTO #Actual VALUES (''tSQLt.Private_EnableCLR'')';
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.InstallAssemblyKey', @CommandToExecute='INSERT INTO #Actual VALUES (''tSQLt.InstallAssemblyKey'')';

  CREATE TABLE #Actual ( OrderNo INT IDENTITY (1,1), ProcedureName NVARCHAR(Max));

  EXEC tSQLt.PrepareServer;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  INSERT INTO #Expected VALUES(1,'tSQLt.Private_EnableCLR'),(2,'tSQLt.InstallAssemblyKey');
  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
  
END;
GO


GO

EXEC tSQLt.NewTestClass 'Private_EnableCLRTests';
GO
CREATE PROCEDURE Private_EnableCLRTests.[test alters value for 'clr enabled' in serverconfigurations]
AS
BEGIN
  EXEC tSQLt.CaptureOutput 'EXEC sys.sp_configure @configname=''clr enabled'', @configvalue=0;';
  
  BEGIN TRY
    EXEC tSQLt.Private_EnableCLR;
  END TRY
  BEGIN CATCH
    PRINT ERROR_MESSAGE();
  END CATCH

  SELECT name,value
    INTO #Actual
    FROM sys.configurations AS C
   WHERE C.name = 'clr enabled';

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  INSERT INTO #Expected VALUES('clr enabled',1);
  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
   
END;
GO
CREATE PROCEDURE Private_EnableCLRTests.[test does not alter other values in serverconfigurations]
AS
BEGIN
  SELECT C.name,
         C.value
    INTO #Expected
    FROM master.sys.configurations AS C
   WHERE name <> 'clr enabled';

  BEGIN TRY
    EXEC tSQLt.Private_EnableCLR;
  END TRY
  BEGIN CATCH
    PRINT ERROR_MESSAGE();
  END CATCH

  SELECT name,value
    INTO #Actual
    FROM sys.configurations AS C
   WHERE C.name <> 'clr enabled';

  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
   
END;
GO
CREATE PROCEDURE Private_EnableCLRTests.[test calls RECONFIGURE]
AS
BEGIN
   EXEC tSQLt.ExpectException @ExpectedMessage = 'CONFIG statement cannot be used inside a user transaction.';

   EXEC tSQLt.Private_EnableCLR;
END;
GO


GO

EXEC tSQLt.NewTestClass 'RemoveAssemblyKeyTests';
GO
DECLARE @cmd NVARCHAR(MAX);
SET @cmd = 'IF(SUSER_ID(''RemoveAssemblyKeyTestsUser1'')) IS NOT NULL DROP LOGIN RemoveAssemblyKeyTestsUser1;';
EXEC master.sys.sp_executesql @cmd;
SET @cmd = 'IF(SCHEMA_ID(''RemoveAssemblyKeyTestsUser1'')) IS NOT NULL DROP SCHEMA RemoveAssemblyKeyTestsUser1;';
EXEC master.sys.sp_executesql @cmd;
EXEC sys.sp_executesql @cmd;
SET @cmd = 'IF(USER_ID(''RemoveAssemblyKeyTestsUser1'')) IS NOT NULL DROP USER RemoveAssemblyKeyTestsUser1;';
EXEC master.sys.sp_executesql @cmd;
EXEC sys.sp_executesql @cmd;
GO
CREATE PROCEDURE RemoveAssemblyKeyTests.DropExistingItems
AS
BEGIN
  IF SUSER_ID('tSQLtAssemblyKey') IS NOT NULL DROP LOGIN tSQLtAssemblyKey;
  EXEC master.sys.sp_executesql N'IF ASYMKEY_ID(''tSQLtAssemblyKey'') IS NOT NULL DROP ASYMMETRIC KEY tSQLtAssemblyKey;';
  EXEC master.sys.sp_executesql N'IF EXISTS(SELECT * FROM sys.assemblies WHERE name = ''tSQLtAssemblyKey'') DROP ASSEMBLY tSQLtAssemblyKey;';
  DECLARE @cmd NVARCHAR(MAX);
  DECLARE @ProductMajorVersion INT;
  EXEC @ProductMajorVersion = tSQLt.Private_GetSQLProductMajorVersion;
  IF(@ProductMajorVersion>=14)
  BEGIN
    -- sp_drop_trusted_assembly is new (and required) in 2017
    DECLARE @TrustedHash NVARCHAR(MAX);
    SELECT @TrustedHash = CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',PGEAKB.UnsignedEmptyBytes),1)
      FROM tSQLt_testutil.GetUnsignedEmptyBytes() AS PGEAKB

    SELECT @cmd = 
           'IF EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash = ' + @TrustedHash +')'+
           'EXEC sys.sp_drop_trusted_assembly @hash = ' + @TrustedHash + ';';
    EXEC master.sys.sp_executesql @cmd;

    DECLARE @AssemblyKeyBytes VARBINARY(MAX);
    EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;

    SELECT @TrustedHash = CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1);

    SELECT @cmd = 
           'IF EXISTS(SELECT 1 FROM sys.trusted_assemblies WHERE hash = ' + @TrustedHash +')'+
           'EXEC sys.sp_drop_trusted_assembly @hash = ' + @TrustedHash + ';';
    EXEC master.sys.sp_executesql @cmd;
  END;
END;
GO
GO
CREATE PROCEDURE RemoveAssemblyKeyTests.[test removes tSQLtAssemblyKey assembly]
AS
BEGIN
  EXEC RemoveAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);

  DECLARE @ProductMajorVersion INT;
  EXEC @ProductMajorVersion = tSQLt.Private_GetSQLProductMajorVersion;
  IF(@ProductMajorVersion>=14)
  BEGIN
    -- sp_add_trusted_assembly is new (and required) in 2017
    SELECT @cmd = 
           'EXEC sys.sp_add_trusted_assembly @hash = ' + CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',PGEAKB.UnsignedEmptyBytes),1) + ', @description = N''tSQLt Ephemeral'';'
      FROM tSQLt_testutil.GetUnsignedEmptyBytes() AS PGEAKB
     WHERE NOT EXISTS(SELECT 1 FROM sys.trusted_assemblies AS TA WHERE TA.hash = HASHBYTES('SHA2_512',PGEAKB.UnsignedEmptyBytes));
  
    EXEC master.sys.sp_executesql @cmd;
  END;

  SELECT @cmd = 
         'CREATE ASSEMBLY tSQLtAssemblyKey AUTHORIZATION dbo FROM ' +
         CONVERT(NVARCHAR(MAX),GUEB.UnsignedEmptyBytes,1) +
         ' WITH PERMISSION_SET = SAFE;'       
    FROM tSQLt_testutil.GetUnsignedEmptyBytes() AS GUEB;
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.RemoveAssemblyKey;

  IF(EXISTS(SELECT 1 FROM master.sys.assemblies WHERE name = 'tSQLtAssemblyKey'))
  BEGIN
    EXEC tSQLt.Fail 'Assembly tSQLtAssemblyKey not removed.';
  END;
END;
GO

CREATE PROCEDURE RemoveAssemblyKeyTests.[test removes tSQLtAssemblyKey asymmetric key]
AS
BEGIN
  EXEC RemoveAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);

  SELECT @cmd = 'CREATE ASYMMETRIC KEY tSQLtAssemblyKey WITH ALGORITHM = RSA_2048 ENCRYPTION BY PASSWORD = '''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''';';
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.RemoveAssemblyKey;

  SELECT *
    INTO #Actual
    FROM master.sys.asymmetric_keys AS AK
   WHERE AK.name = 'tSQLtAssemblyKey'

  EXEC tSQLt.AssertEmptyTable @TableName = '#Actual'; --<-- this might blow up if the table isn't empty.
END;
GO

CREATE PROCEDURE RemoveAssemblyKeyTests.[test removes tSQLtAssemblyKey login]
AS
BEGIN
  EXEC RemoveAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);

  SELECT @cmd = 'CREATE LOGIN tSQLtAssemblyKey WITH PASSWORD = '''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''',CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;';
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.RemoveAssemblyKey;

  SELECT *
    INTO #Actual
    FROM master.sys.server_principals AS SP
   WHERE SP.name = 'tSQLtAssemblyKey'

  EXEC tSQLt.AssertEmptyTable @TableName = '#Actual'; --<-- this might blow up if the table isn't empty.
END;
GO

CREATE PROCEDURE RemoveAssemblyKeyTests.[test removes tSQLtAssemblyKey asymmetric key and login in correct order]
AS
BEGIN
  EXEC RemoveAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);

  SELECT @cmd = 'CREATE ASYMMETRIC KEY tSQLtAssemblyKey WITH ALGORITHM = RSA_2048 ENCRYPTION BY PASSWORD = '''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''';';
  EXEC master.sys.sp_executesql @cmd;
  SELECT @cmd = 'CREATE LOGIN tSQLtAssemblyKey FROM ASYMMETRIC KEY tSQLtAssemblyKey;';
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.RemoveAssemblyKey;

  SELECT *
    INTO #Actual
    FROM
    (  
      SELECT AK.name
        FROM master.sys.asymmetric_keys AS AK
       WHERE AK.name = 'tSQLtAssemblyKey'
      UNION ALL
      SELECT SP.name
        FROM master.sys.server_principals AS SP
       WHERE SP.name = 'tSQLtAssemblyKey'
    )A

  EXEC tSQLt.AssertEmptyTable @TableName = '#Actual'; --<-- this might blow up if the table isn't empty.
END;
GO

CREATE PROCEDURE RemoveAssemblyKeyTests.[test non-sysadmin cannot execute procedure]
AS
BEGIN
  DECLARE @cmd NVARCHAR(MAX);
    
  SET @cmd = 'CREATE LOGIN RemoveAssemblyKeyTestsUser1 WITH PASSWORD='''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''';';
  EXEC master.sys.sp_executesql @cmd;

  SET @cmd = 'CREATE USER RemoveAssemblyKeyTestsUser1;ALTER ROLE db_owner ADD MEMBER RemoveAssemblyKeyTestsUser1;';
  IF((SELECT I.SqlVersion FROM tSQLt.Info() AS I) < 11)
  BEGIN
    SET @cmd = 'CREATE USER RemoveAssemblyKeyTestsUser1;EXEC sys.sp_addrolemember @rolename = ''db_owner'', @membername = ''RemoveAssemblyKeyTestsUser1'';';
  END
  EXEC master.sys.sp_executesql @cmd;
  EXEC sys.sp_executesql @cmd;
  
  EXEC tSQLt.ExpectException @ExpectedMessage = 'Only principals with CONTROL SERVER permission can execute this procedure.';
  
  EXECUTE AS LOGIN = 'RemoveAssemblyKeyTestsUser1';
  EXEC tSQLt.RemoveAssemblyKey;
  REVERT;

END;
GO

CREATE PROCEDURE RemoveAssemblyKeyTests.[test login with control server permission can execute procedure]
AS
BEGIN

    EXEC RemoveAssemblyKeyTests.DropExistingItems;

    DECLARE @cmd NVARCHAR(MAX);
    
    SET @cmd = 'CREATE LOGIN RemoveAssemblyKeyTestsUser1 WITH PASSWORD='''+(SELECT PW FROM tSQLt_testutil.GenerateRandomPassword(NEWID()))+''';';
    EXEC master.sys.sp_executesql @cmd;

    SET @cmd = 'GRANT CONTROL SERVER TO RemoveAssemblyKeyTestsUser1;';
    EXEC master.sys.sp_executesql @cmd;
  
    EXEC tSQLt.ExpectNoException;
  
    EXECUTE AS LOGIN = 'RemoveAssemblyKeyTestsUser1';
      EXEC tSQLt.RemoveAssemblyKey;
    REVERT;

END;
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE RemoveAssemblyKeyTests.[test removes trusted assembly record if it exists]
AS
BEGIN
  EXEC RemoveAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);
  DECLARE @AssemblyKeyBytes VARBINARY(MAX);
  DECLARE @TrustedHash NVARCHAR(MAX);

  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;
  SELECT @TrustedHash = CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1);

  SELECT @cmd = 'EXEC sys.sp_add_trusted_assembly @hash = ' + @TrustedHash +',@description = N''tSQLt Ephemeral'';'  
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.RemoveAssemblyKey;

  IF(EXISTS(SELECT 1 FROM master.sys.trusted_assemblies WHERE hash = CONVERT(VARBINARY(MAX),@TrustedHash,1)))
  BEGIN
    EXEC tSQLt.Fail 'Trusted Assembly record for tSQLtAssemblyKey not removed.';
  END;
END;
GO
--[@tSQLt:MinSqlMajorVersion](14)
CREATE PROCEDURE RemoveAssemblyKeyTests.[test doesn't remove trusted assembly record if it is not 'tSQLt Ephemeral']
AS
BEGIN
  EXEC RemoveAssemblyKeyTests.DropExistingItems;

  DECLARE @cmd NVARCHAR(MAX);
  DECLARE @AssemblyKeyBytes VARBINARY(MAX);
  DECLARE @TrustedHash NVARCHAR(MAX);

  EXEC tSQLt.Private_GetAssemblyKeyBytes @AssemblyKeyBytes = @AssemblyKeyBytes OUT;
  SELECT @TrustedHash = CONVERT(NVARCHAR(MAX),HASHBYTES('SHA2_512',@AssemblyKeyBytes),1);

  SELECT @cmd = 'EXEC sys.sp_add_trusted_assembly @hash = ' + @TrustedHash +',@description = N''something else'';'  
  EXEC master.sys.sp_executesql @cmd;
  
  EXEC tSQLt.RemoveAssemblyKey;

  IF(NOT EXISTS(SELECT 1 FROM master.sys.trusted_assemblies WHERE hash = CONVERT(VARBINARY(MAX),@TrustedHash,1)))
  BEGIN
    EXEC tSQLt.Fail 'Trusted Assembly record for tSQLtAssemblyKey removed despite description <> ''tSQLt Ephemeral''.';
  END;
END;
GO


GO

EXEC tSQLt.NewTestClass 'RemoveExternalAccessKeyTests';
GO
CREATE PROCEDURE RemoveExternalAccessKeyTests.[test calls tSQLt.RemoveAssemblyKey]
AS
BEGIN
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.RemoveAssemblyKey';

  EXEC tSQLt.RemoveExternalAccessKey;

  SELECT _id_ INTO #Actual FROM tSQLt.RemoveAssemblyKey_SpyProcedureLog;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  
  INSERT INTO #Expected VALUES (1);

  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
  
END;
GO

CREATE PROCEDURE RemoveExternalAccessKeyTests.[test prints sensible deprecation warning]
AS
BEGIN
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.RemoveAssemblyKey';
  EXEC tSQLt.SpyProcedure @ProcedureName = 'tSQLt.Private_Print';

  EXEC tSQLt.RemoveExternalAccessKey;

  SELECT Message INTO #Actual FROM tSQLt.Private_Print_SpyProcedureLog ;

  SELECT TOP(0) A.* INTO #Expected FROM #Actual A RIGHT JOIN #Actual X ON 1=0;
  INSERT INTO #Expected VALUES('tSQLt.RemoveExternalAccessKey is deprecated. Please use tSQLt.RemoveAssemblyKey instead.');

  EXEC tSQLt.AssertEqualsTable '#Expected','#Actual';
  
END;
GO


GO


EXEC tSQLt.InstallAssemblyKey;

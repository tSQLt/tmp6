:EXIT(SELECT COUNT(*) FROM tSQLt.TestResult WHERE Result != 'Success')


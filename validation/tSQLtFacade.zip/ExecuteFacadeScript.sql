    :r FacadeScript.sql
    GO
    EXEC Facade.CreateAllFacadeObjects @FacadeDbName='$(FacadeTargetDb)';
    GO

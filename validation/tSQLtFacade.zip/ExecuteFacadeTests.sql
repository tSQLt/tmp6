    :r FacadeScript.sql
    GO
    :r FacadeTests.sql
    GO
    EXEC tSQLt.RunAll;
    GO

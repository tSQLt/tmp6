    :r FacadeScript.sql
    GO
    :r FacadeTests.sql
    GO

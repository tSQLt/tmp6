This zip file contains a set of SQL Prompt snippets for use with Red Gate SQL Prompt.

Red Gate SQL Prompt is not part of tSQLt and not required to use tSQLt. 
You can get it here:http://www.red-gate.com/products/sql-development/sql-prompt/

To install the tSQLt snippets, unzip this zip file into the SQL Prompt Snippet Directory.
This directory is usually located in "AppData\Local\Red Gate\SQL Prompt 6\Snippets"
under your local user directory.